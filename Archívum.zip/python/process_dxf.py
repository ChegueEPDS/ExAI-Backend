import sys
import ezdxf
import re
import json
import pandas as pd
from openpyxl import Workbook
from math import hypot

if len(sys.argv) < 2:
    print("Hiba: nincs fájlmegadás.", file=sys.stderr)
    sys.exit(1)

dxf_path = sys.argv[1]

try:
    doc = ezdxf.readfile(dxf_path)
except Exception as e:
    print(f"Hiba a DXF beolvasásakor: {e}", file=sys.stderr)
    sys.exit(1)

msp = doc.modelspace()
lines = []
texts = []
fittings = {}

dn_pattern = re.compile(r"(?:DN|Ø|D\.?)\s*(\d+)", re.IGNORECASE)

# Vonalak beolvasása
for e in msp:
    if e.dxftype() == 'LINE':
        lines.append({
            "start": e.dxf.start,
            "end": e.dxf.end
        })

# Szövegek (DN jelölések)
for e in msp.query('TEXT MTEXT'):
    text = e.plain_text() if e.dxftype() == 'MTEXT' else e.dxf.text
    match = dn_pattern.search(text)
    if match:
        texts.append({
            "text": f"DN{match.group(1)}",
            "position": e.dxf.insert
        })

# Közelség alapján DN hozzárendelése
def midpoint(p1, p2):
    return ((p1[0]+p2[0])/2, (p1[1]+p2[1])/2)

pipe_data = []
for line in lines:
    mp = midpoint(line['start'], line['end'])
    closest_dn = None
    min_dist = float('inf')
    for t in texts:
        dist = hypot(t['position'][0] - mp[0], t['position'][1] - mp[1])
        if dist < 20 and dist < min_dist:
            min_dist = dist
            closest_dn = t['text']
    length = hypot(line['end'][0] - line['start'][0], line['end'][1] - line['start'][1])
    pipe_data.append({
        "length": round(length, 2),
        "dn": closest_dn or "unknown"
    })

# Blokkok (INSERT) szűrése
for e in msp.query('INSERT'):
    name = e.dxf.name.upper()
    for key in ["ELBOW", "T_IDOM", "VALVE"]:
        if key in name:
            fittings[key] = fittings.get(key, 0) + 1

# Excel export
wb = Workbook()
ws = wb.active
ws.title = "Pipes"
ws.append(["DN", "Length"])
for p in pipe_data:
    ws.append([p["dn"], p["length"]])

ws2 = wb.create_sheet("Fittings")
ws2.append(["Type", "Count"])
for k, v in fittings.items():
    ws2.append([k, v])

excel_path = f"results/output_{int(pd.Timestamp.now().timestamp())}.xlsx"
wb.save(excel_path)

# JSON kimenet
output = {
    "pipes": pipe_data,
    "fittings": [{"type": k, "count": v} for k, v in fittings.items()],
    "excel_path": excel_path
}

print(json.dumps(output))