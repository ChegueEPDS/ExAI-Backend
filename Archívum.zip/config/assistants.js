const assistants = {
    'default': process.env.ASSISTANT_ID_DEFAULT,
    'PGMED': process.env.ASSISTANT_ID_PGMED,
    'Viresol': process.env.ASSISTANT_ID_VIRESOL,
    'XIII': process.env.ASSISTANT_ID_XIII,
    'TUZ': process.env.ASSISTANT_ID_TUZ,
    'STAND98': process.env.ASSISTANT_ID_STAND98,
    'BGC': process.env.ASSISTANT_ID_BGC,
    'DRND': process.env.ASSISTANT_ID_DRND,
    'archicon': process.env.ASSISTANT_ID_ARCHICON,
    'robex':process.env.ASSISTANT_ID_ROBEX,
    'wolff':process.env.ASSISTANT_ID_WOLFF
  };
  
  module.exports = assistants;